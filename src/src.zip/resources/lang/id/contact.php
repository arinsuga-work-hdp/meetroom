<?php

return [
    'contactus' => 'Hubungi Kami',
    'purpose' => 'Purpose',
    'firstname' => 'First Name',
    'lastname' => 'Last Name',
    'email_address' => 'Email Address',
    'information' => 'I certify that all of the above information are correct',
    'send' => 'SEND',
];
