<?php

return [
    'title' => 'PRODUKSI',
    'title1' => 'Teknologi Material',
    'desc1' => 'Bahan baku berstandar internasional dimana setiap bahan memiliki kualitas terbaik sesuai dengan spesifikasi peralatan perkebunan yang dibutuhkan',

    'title2' => 'Teknologi Pengolahan Bahan dengan Detail',
    'desc2' => 'Teknologi dan komputerisasi baru dalam pengolahan baja untuk menghasilkan peralatan yang berkualitas tinggi',

    'title3' => 'Team Produksi Kami',
    'desc3' => 'Didukung oleh tenaga kerja yang berkualitas dalam setiap proses produksi. Mulai dari pembentuk material, pembentuk bilah, pengolahan baja, hingga finishing',

    'title4' => 'Dirancang untuk Pengguna Bijak',
    'desc4' => 'Fokus pada setiap detail desain produk kami untuk memberikan pengalaman pengguna terbaik melalui penelitian dan pengembangan',

];
