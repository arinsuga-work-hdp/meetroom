<?php

return [
    'title' => 'DISTRIBUTOR NASIONAL',
    'desc1' => 'Dalam menjalankan kegiatan distribusi, PT. Malindo Agrotek Perkasa memiliki 8 kantor perwakilan di seluruh Indonesia dan terus berkembang. Didukung oleh jaringan distribusi berskala nasional, tim yang profesional dan berkualitas, berkomitmen, berintegritas tinggi untuk melaksanakan strategi perusahaan dengan tanggung jawab secara berkelanjutan',
    'desc2' => 'PT. Malindo Agrotek Perkasa menawarkan solusi teknologi mulai dari persiapan, perlindungan dan pengolahan usaha pertanian',
    'desc3' => 'PT. Malindo Agrotek Perkasa adalah penyedia teknologi di bidang pertanian yang bisa Anda andalkan',
    'partners' => 'PARTNER KAMI',
];
