<?php

return [
    'home' => 'Home',
    'about' => 'About Us',
    'product' => 'Product',
    'branch' => 'Branch Location',
    'event' => 'Event & News',
    'contact' => 'Contact Us',
    'shop' => 'Shop',
    'language' => 'Language',
];
