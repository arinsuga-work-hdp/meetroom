<?php
namespace Arins\Helpers\Converter\Number;

interface ConvertInterface extends ConvertStringToNumberInterface
{
    /**
     * ======================================================
     * 1. Inherit from ConvertStringToNumberInterface
     * ====================================================== */

}
