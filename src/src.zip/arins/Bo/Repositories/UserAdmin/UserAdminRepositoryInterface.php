<?php

namespace Arins\Bo\Repositories\UserAdmin;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface UserAdminRepositoryInterface extends BaseRepositoryInterface
{
}