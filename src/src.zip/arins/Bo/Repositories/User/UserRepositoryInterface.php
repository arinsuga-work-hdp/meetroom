<?php

namespace Arins\Bo\Repositories\User;

interface UserRepositoryInterface
{
    function all();
    function allBO();
}