<?php

namespace Arins\Repositories\Employee;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface EmployeeRepositoryInterface extends BaseRepositoryInterface
{
}