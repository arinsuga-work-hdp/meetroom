<?php

namespace Arins\Repositories\Orderstatus;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface OrderstatusRepositoryInterface extends BaseRepositoryInterface
{
}