<?php

namespace Arins\Repositories\Job;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface JobRepositoryInterface extends BaseRepositoryInterface
{
}