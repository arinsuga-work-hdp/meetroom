<?php

namespace Arins\Repositories\Dept;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface DeptRepositoryInterface extends BaseRepositoryInterface
{
}