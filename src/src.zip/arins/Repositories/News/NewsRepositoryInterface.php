<?php

namespace Arins\Repositories\News;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface NewsRepositoryInterface extends BaseRepositoryInterface
{
}