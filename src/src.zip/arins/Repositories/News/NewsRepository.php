<?php

namespace Arins\Repositories\News;

use Arins\Repositories\BaseRepository;
use Arins\Repositories\News\NewsRepositoryInterface;

class NewsRepository extends BaseRepository implements NewsRepositoryInterface
{
}