<?php

namespace Arins\Repositories\Subdept;

use Arins\Repositories\BaseRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface SubdeptRepositoryInterface extends BaseRepositoryInterface
{
}