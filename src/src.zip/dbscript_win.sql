-- Script for database
source dbscripts\dbmeetroom_custom_view.sql
